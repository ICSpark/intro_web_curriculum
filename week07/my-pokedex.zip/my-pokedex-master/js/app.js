//Use the Document Object Model (DOM) to complete the following exercises below:


// Pokemon 1
// Find the div with the id of "name1" and replace the text n/a with "Tentacool"
// Place your code below



// Pokemon 2
// Find the div with the id of "type2" and replace the text n/a with "water"
// Place your code below




// Pokemon 3
// Find the div with the id of "pokeNumber3" and replace the text n/a with 116:
// Place your code below





// Pokemon 4
// Find the div with the id of "bio4" and replace the text n/a with your personal description of this Pokemon.
// Place your code below





// Pokemon 5
// Find the div with the id of "bio5" and replace the the font color to "red";
// Place your code below





// Pokemon 6
// Find the div with the id of "name6" and replace the font size to "60px";
// Place your code below





// Pokemon 7
// Find the div with the id of "container" and change the background color to "green"
// Place your code below


