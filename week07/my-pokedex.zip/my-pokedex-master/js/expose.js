// Tentacool Expose
var tentacool = document.getElementById("name1");
if (tentacool.innerHTML === "Tentacool"){
  document.getElementById("showTentacool").src = "https://vignette.wikia.nocookie.net/pokemon/images/4/4e/072Tentacool.png/revision/latest/scale-to-width-down/200?cb=20140328203939";
}

// MagiKarp Expose
var tentacool = document.getElementById("type2");
if (tentacool.innerHTML === "water"){
  document.getElementById("showMagikarp").src = "https://vignette.wikia.nocookie.net/pokemon/images/0/02/129Magikarp.png/revision/latest/scale-to-width-down/200?cb=20140328210352";
}

// Magikarp Expose
var magikarp = document.getElementById("type2");
if (magikarp.innerHTML === "water"){
  document.getElementById("showMagikarp").src = "https://vignette.wikia.nocookie.net/pokemon/images/0/02/129Magikarp.png/revision/latest/scale-to-width-down/200?cb=20140328210352";
}

// Horsea Expose
var horsea = document.getElementById("pokeNumber3");
if (horsea.innerHTML === "116"){
  document.getElementById("showHorsea").src = "https://vignette.wikia.nocookie.net/pokemon/images/5/5a/116Horsea.png/revision/latest/scale-to-width-down/200?cb=20140328205800";
}

// Kingler Expose
var kingler = document.getElementById("bio4");
if (kingler.innerHTML !== "n/a"){
  document.getElementById("showKingler").src = "https://vignette.wikia.nocookie.net/pokemon/images/7/71/099Kingler.png/revision/latest/scale-to-width-down/200?cb=20140328204636";
}

// Gyarados Expose
var gyarados = document.getElementById("bio5");
if (gyarados.style.color === "red"){
  document.getElementById("showGyarados").src = "https://vignette.wikia.nocookie.net/pokemon/images/4/41/130Gyarados.png/revision/latest?cb=20140328210352";
}

// Seadra Expose
var seadra = document.getElementById("name6");
if (seadra.style.fontSize === "60px"){
  document.getElementById("showSeadra").src = "https://vignette.wikia.nocookie.net/pokemon/images/2/26/117Seadra.png/revision/latest/scale-to-width-down/200?cb=20140328205801";
}

// Psyduck Expose
var psyduck = document.getElementById("container");
if (psyduck.style.backgroundColor === "green"){
  document.getElementById("showPsyduck").src = "https://vignette.wikia.nocookie.net/pokemon/images/5/53/054Psyduck.png/revision/latest/scale-to-width-down/200?cb=20140328195856";
}